# Phase1 Data Inventory

Phase1 uses only public price and accounting fields already present in the repository.
Future Moat, AI keyword, Transformation, and existing proprietary BEYOND BUFFETT scores are not used for selection.

## data/processed/universe.csv

- Columns: effective_date, code, ticker, company_name, market, sector_33_code, sector_33, sector_17_code, sector_17, scale_category_code, scale_category, is_financial
- Code column: code
- Ticker column: ticker
- Date columns: effective_date

## data/processed/scores.csv

- Columns: effective_date, code, ticker, company_name, market, sector_33_code, sector_33, sector_17_code, sector_17, scale_category_code, scale_category, is_financial, latest_date, close, adj_close, volume, avg_trading_value_60d, history_days, daily_return_mean, annual_volatility, max_drawdown, return_12m_ex_1m, cumulative_return, price_history_days, company_name_ja, revenue, operating_income, ordinary_income, net_income, total_assets, equity, operating_cf, investing_cf, financing_cf, rd_expense, capex, employees, revenue_growth, operating_income_growth, operating_margin, roe, equity_ratio, ocf_margin, rd_ratio, capex_ratio, market_cap, enterprise_value, trailing_pe, forward_pe, price_to_book, dividend_yield, beta, shares_outstanding, ebitda, dividend_yield_clean, pe_for_score, pbr_for_score, is_financial_like, ordinary_margin, net_margin, profitability_score, cash_generation_score, stability_score, competitive_position_score, score_treatment, moat_score, moat_component_profitability, moat_component_cashflow, moat_component_stability, moat_component_competitive_position, transformation_score, transformation_component_valuation_gap, transformation_component_capital_efficiency, transformation_component_shareholder_return, transformation_component_reform_signal, ai_infrastructure_exposure, automation_exposure, data_software_exposure, trust_security_exposure, intangible_investment_score, future_moat_component_ai_infrastructure, future_moat_component_intangible_asset, future_moat_component_automation, future_moat_component_data, future_moat_component_trust, future_moat_score, future_moat_category_flags, future_moat_keyword_evidence, valuation_score, bb_score, momentum_score, risk_score, adjusted_bb_score, price_available, liquid_20m_60d, operating_loss_years_3y, operating_income_years_available, ordinary_loss_years_3y, ordinary_income_years_available, net_loss_years_3y, net_income_years_available, negative_ocf_years_3y, operating_cf_years_available, investment_exclusion_reasons, investment_eligible, score_calculation_target, moat_rank, moat_percentile, transformation_rank, transformation_percentile, future_moat_rank, future_moat_percentile, valuation_rank, valuation_percentile, momentum_rank, momentum_percentile, risk_rank, risk_percentile, adjusted_bb_rank, adjusted_bb_percentile, category, score_rank
- Code column: code
- Ticker column: ticker
- Date columns: effective_date, latest_date

## data/processed/fundamentals_clean.csv

- Columns: code, ticker, company_name, company_name_ja, market, sector_33, sector_17, scale_category, is_financial, revenue, operating_income, ordinary_income, net_income, total_assets, equity, operating_cf, investing_cf, financing_cf, rd_expense, capex, employees, revenue_growth, operating_income_growth, operating_margin, roe, equity_ratio, ocf_margin, rd_ratio, capex_ratio, market_cap, enterprise_value, trailing_pe, forward_pe, price_to_book, dividend_yield, beta, shares_outstanding, ebitda
- Code column: code
- Ticker column: ticker
- Date columns: none

## data/processed/fundamentals_raw.csv

- Columns: code, ticker, doc_id, filer_name, submit_date, period_start, period_end, revenue, operating_income, ordinary_income, net_income, total_assets, equity, operating_cf, investing_cf, financing_cf, rd_expense, capex, employees
- Code column: code
- Ticker column: ticker
- Date columns: submit_date, period_start, period_end

## data/processed/latest_prices.csv

- Columns: ticker, latest_date, close, adj_close, volume, avg_trading_value_60d, history_days
- Code column: not present
- Ticker column: ticker
- Date columns: latest_date

## data/processed/yfinance_metrics.csv

- Columns: ticker, market_cap, enterprise_value, trailing_pe, forward_pe, price_to_book, dividend_yield, beta, shares_outstanding, ebitda, currency, quote_type
- Code column: not present
- Ticker column: ticker
- Date columns: none

## data/processed/prices_daily.parquet

- Columns: date, ticker, open, high, low, close, adj_close, volume
- Code column: not present
- Ticker column: ticker
- Date columns: date

## Missing Variables For Original Academic Formulas

- Gross Profitability: gross profit or cost of goods sold is not available, so the Novy-Marx original formula is unavailable.
- QMJ full: payout, equity issuance, debt issuance, idiosyncratic volatility, earnings volatility, and full growth components are unavailable.
- Piotroski full: gross margin, current ratio, and common equity issuance are unavailable; available-signal reliability is reported.
- Ohlson O-Score: GNP, working capital, current assets, current liabilities, FFO, and CHIN inputs are unavailable.
- Altman Z-Score: working capital and retained earnings are unavailable; original Altman Z is therefore unavailable.
